import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Receiver {
	public static void main(String args []) throws Exception{
		try {
			ServerSocket ss = new ServerSocket(8081);
			System.out.println("Receiver is running on port 8081...");
			
			while(true){
				Socket s = ss.accept();
				DataInputStream in = new DataInputStream(s.getInputStream());
				String strSender = in.readUTF();
				
				String strToSend = "";
				
				try{
					int intCast = Integer.parseInt(strSender.trim());
					
					if(intCast % 2 == 0){
						strToSend = "You sent even number";
					}
					else{
						strToSend = "You sent odd number";
					}
					} catch(NumberFormatException pe){
					strToSend = "Please send a number la!";
				}
				
				DataOutputStream out = new DataOutputStream(s.getOutputStream());
				out.writeUTF(strToSend);
				s.close();
				}
			} catch (Exception e) {
            e.printStackTrace();
        }
	}
}
