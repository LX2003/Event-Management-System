package gui;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextArea;

public class Sender {

	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) throws Exception{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sender window = new Sender();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Sender() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("BITP 3213 Lab 6");
		lblNewLabel.setBounds(164, 10, 91, 24);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Add String Here");
		lblNewLabel_1.setBounds(10, 31, 103, 24);
		frame.getContentPane().add(lblNewLabel_1);
		
		JTextField inputField = new JTextField();
		inputField.setBounds(10, 65, 175, 24);
		frame.getContentPane().add(inputField);
		inputField.setColumns(10);
		
		JButton btnSend = new JButton("Send");
		btnSend.setBounds(205, 66, 85, 21);
		frame.getContentPane().add(btnSend);
		
		JLabel lblNewLabel_2 = new JLabel("Output:");
		lblNewLabel_2.setBounds(10, 108, 77, 13);
		frame.getContentPane().add(lblNewLabel_2);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(10, 131, 208, 97);
		frame.getContentPane().add(textArea);
		
		JLabel image = new JLabel("");
		image.setBounds(273, 131, 141, 97);
		frame.getContentPane().add(image);
		
		JButton btnGetImage = new JButton("Get Image");
		btnGetImage.setBounds(295, 104, 85, 21);
		frame.getContentPane().add(btnGetImage);
		
		btnGetImage.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
		            Socket varSock = new Socket("127.0.0.1", 8082);
		            BufferedImage buffImg = ImageIO.read(ImageIO.createImageInputStream(varSock.getInputStream()));
		            
		            Image scaledImage = buffImg.getScaledInstance(
		            	    image.getWidth(),
		            	    image.getHeight(),
		            	    Image.SCALE_SMOOTH
		            	);
		            ImageIcon varImgIcon = new ImageIcon(scaledImage);
		            image.setIcon(varImgIcon);
		        } catch (UnknownHostException ex) {
		        	ex.printStackTrace();
		        	
		        } catch (IOException e1) {
		            e1.printStackTrace();
		        }
			}
		});
		
		btnSend.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Runnable run = new Runnable() {
					@Override
					public void run() {
						try {
		                    Socket s = new Socket("127.0.0.1", 8081);
		                    DataOutputStream out = new DataOutputStream(s.getOutputStream());
		                    
		                    String strTxtFld1 = inputField.getText();
		                    out.writeUTF(strTxtFld1);
		                    
		                    DataInputStream in = new DataInputStream(s.getInputStream());
		                    String strReceiver = in.readUTF();
		                    
		                    textArea.setText(textArea.getText()+"\n" + strReceiver);
		                    
		                    
		                    } catch (UnknownHostException e) {
		                    	e.printStackTrace();
		                    } catch (IOException e) {
		                    	e.printStackTrace();
		                    }
					}
					
				};
				Thread thr1 = new Thread(run);
				thr1.start();
			}
		});
	}
}
