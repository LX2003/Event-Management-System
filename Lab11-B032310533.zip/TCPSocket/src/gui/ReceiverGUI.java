package gui;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JTextArea;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFileChooser;

public class ReceiverGUI {

	private JFrame frame;
	private JTextField textField;
	private JTextArea textArea;
	private ServerSocket serverSocket;
	private Socket socket;
	private DataInputStream in;
	private DataOutputStream out;
	private JTextField textFieldURL;
	
	private void startImageServer() {
	    Runnable run = new Runnable(){
	    	@Override
	    	public void run() {
		        try (ServerSocket imageServerSocket = new ServerSocket(8082)) {
		            System.out.println("Image server running on port 8082...");
		            while (true) {
		                try (Socket clientSocket = imageServerSocket.accept()) {
		                    if (textFieldURL.getText() == null || textFieldURL.getText().isEmpty()) {
		                        System.out.println("No image selected to send.");
		                        continue;
		                    }
		                    File imageFile = new File(textFieldURL.getText());
		                    BufferedImage image = ImageIO.read(imageFile);
		                    String extension = imageFile.getName().substring(imageFile.getName().lastIndexOf(".") + 1);
		                    ImageIO.write(image, extension, clientSocket.getOutputStream());
		                    System.out.println("Image sent to sender.");
		                } catch (IOException e) {
		                    e.printStackTrace();
		                }
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        }
	    	}
	    };
	    Thread thr1 = new Thread(run);
	    thr1.start();
	}

	public static void main(String[] args) throws Exception{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ReceiverGUI window = new ReceiverGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public ReceiverGUI() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("String Receive");
		lblNewLabel.setBounds(10, 24, 89, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Message");
		lblNewLabel_1.setBounds(10, 65, 65, 20);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(93, 25, 96, 19);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textArea = new JTextArea();
		textArea.setBounds(85, 65, 143, 76);
		frame.getContentPane().add(textArea);
		
		JButton btnSend = new JButton("Send to Sender");
		btnSend.setBounds(108, 151, 109, 20);
		frame.getContentPane().add(btnSend);
		
		JButton btnSelect = new JButton("Select image to send");
		btnSelect.setBounds(108, 181, 132, 20);
		frame.getContentPane().add(btnSelect);
		
		btnSelect.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser();
			    int option = fileChooser.showOpenDialog(frame);
			    if (option == JFileChooser.APPROVE_OPTION) {
			        File imageFile = fileChooser.getSelectedFile();
			        textFieldURL.setText(imageFile.getAbsolutePath());
			        
			        try (Socket socket = new Socket("127.0.0.1", 8082)) {
			            BufferedImage image = ImageIO.read(imageFile);
			            String extension = imageFile.getName().substring(imageFile.getName().lastIndexOf(".") + 1);
			            ImageIO.write(image, extension, socket.getOutputStream());
			            JOptionPane.showMessageDialog(frame, "Image upload successfully!");
			        } catch (IOException ex) {
			            ex.printStackTrace();
			        }
			    }
			}
		});
		textFieldURL = new JTextField();
		textFieldURL.setBounds(108, 211, 163, 20);
		frame.getContentPane().add(textFieldURL);
		textFieldURL.setColumns(10);
		
		JButton btnSendImage = new JButton("Send this image to sender");
		btnSendImage.setBounds(290, 210, 89, 21);
		frame.getContentPane().add(btnSendImage);
		
		btnSendImage.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try
				{
					if (out != null)
					{
						String reply = textArea.getText().trim();
						out.writeUTF(reply);
						out.flush();
					}
					else 
					{
						JOptionPane.showMessageDialog(frame, "No sender connected.");
					}
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		});
	}
		
		private void startServer() {
			Runnable run = new Runnable(){
				@Override
				public void run() {
					try {
						serverSocket = new ServerSocket(8081);
						System.out.println("Receiver running... Waiting for sender...");
						while (true) {
							socket = serverSocket.accept();
							System.out.println("Sender connected!");
	
							in = new DataInputStream(socket.getInputStream());
							out = new DataOutputStream(socket.getOutputStream());
	
							String received = in.readUTF();
							SwingUtilities.invokeLater(() -> textField.setText(received));
							String strToSend = "empty";
							
							try {
								int intCast = Integer.parseInt(received.trim());
								if(intCast % 2 == 0)
								{
									strToSend = "You sent even number";
								}
								else
								{
									strToSend = "You sent odd number";
								}
	
							
							} catch (NumberFormatException e) {
								strToSend = "Please send a number la!";
							}finally
							{
								textArea.setText(strToSend);
							}
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
			}
		};
		Thread thr1 = new Thread(run);
		thr1.start();
	}
		
		
}